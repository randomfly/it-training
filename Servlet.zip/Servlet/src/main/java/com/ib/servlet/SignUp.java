package com.ib.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.support.SpringBeanAutowiringSupport;

/**
 * Servlet implementation class Signup
 */
@WebServlet({ "/signup" })
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUp() {
        // TODO Auto-generated constructor stub
    }

	/*
	 * @Override public void init() throws ServletException{
	 * SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,
	 * getServletContext()); }
	 */
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		/*
		 * //recuperation du dispatcher RequestDispatcher requestDispatcher =
		 * request.getRequestDispatcher("WEB-INF/jsp/signup.jsp");
		 * 
		 * //forward vers la jsp de la reponse requestDispatcher.forward(request,
		 * response);
		 */
		
		PrintWriter out = response.getWriter();
		out.append("coucou ma servlet signup " + new Date());		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String erreur = "";
		//recuperation du dispatcher
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/jsp/signupGood.jsp");

		//recuperation des identifiants
		String nom = request.getParameter("nom");
		String prenom = request.getParameter("prenom");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		// controle des champs du formulaire
		if (nom == null || nom.isEmpty()) {
			// champ nom obligatoire
			erreur += "champ nom obligatoire<br />";
		}
		if (prenom == null || prenom.isEmpty()) {
			// champ prenom obligatoire
			erreur += "champ prenom obligatoire<br />";
		}
		if (email == null || email.isEmpty()) {
			// champ email obligatoire
			erreur += "champ email obligatoire<br />";
		}
		if (password == null || password.isEmpty()) {
			// champ password obligatoire
			erreur += "champ password obligatoire<br />";
		}
		
		String login = prenom.substring(0, 1) + nom;
		
		PrintWriter out = response.getWriter();
		out.append("coucou ma servlet " + new Date());
	}

}
